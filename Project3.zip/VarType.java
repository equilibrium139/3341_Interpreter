enum VarType
{
    INT, REF
}